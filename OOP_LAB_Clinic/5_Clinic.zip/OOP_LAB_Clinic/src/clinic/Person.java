package clinic;

import clinic.Doctor;

public class Person {
	
	public String getSSN(){
		return null;
	}

	public String getFirst() {
		return null;
	}

	public String getLast() {
		return null;
	}

	public Doctor getDoctor() {
		return null;
	}

}
