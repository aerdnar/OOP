package clinic;

import java.util.Collection;

public class Doctor extends Person {

	public int getId(){
		return -1;
	}
	
	public String getSpecialization(){
		return null;
	}
	
	public Collection<Person> getPatients() {
		return null;
	}

}
