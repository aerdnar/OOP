package university;

public class University {

	public University(String name){
		//TODO: to be implemented
	}
	
	public String getName(){
		//TODO: to be implemented
		return null;
	}
	
	public void setRector(String first, String last){
		//TODO: to be implemented
	}
	
	public String getRector(){
		//TODO: to be implemented
		return null;
	}
	
	public int enroll(String first, String last){
		//TODO: to be implemented
		return -1;
	}
	
	public String student(int id){
		//TODO: to be implemented
		return null;
	}
	
	public int activate(String title, String teacher){
		//TODO: to be implemented
		return -1;
	}
	
	public String course(int code){
		//TODO: to be implemented
		return null;
	}
	
	public void register(int studentID, int courseCode){
		//TODO: to be implemented
	}
	
	public String listAttendees(int courseCode){
		//TODO: to be implemented
		return null;
	}

	public String studyPlan(int studentID){
		//TODO: to be implemented
		return null;
	}
}
