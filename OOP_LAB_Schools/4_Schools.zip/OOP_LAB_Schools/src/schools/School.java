package schools;

import java.util.Collection;

public class School {

	public String getName() {
		return null;
	}

	public String getCode() {
		return null;
	}

	public int getGrade() {
		return -1;
	}

	public String getDescription() {
		return null;
	}

	public Collection<Branch> getBranches() {
		return null;
	}

}
