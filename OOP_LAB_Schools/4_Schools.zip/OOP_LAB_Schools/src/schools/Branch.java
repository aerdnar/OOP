package schools;

public class Branch {
	
	public int getCode() {
		return -1;
	}
	
	public String getAddress() {
		return null;
	}
	
	public int getCAP() {
		return -1;
	}

	public Municipality getMunicipality(){
		return null;
	}

	public School getSchool(){
		return null;
	}

}
