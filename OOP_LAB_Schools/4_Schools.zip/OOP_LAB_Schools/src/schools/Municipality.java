package schools;

import java.util.Collection;
import java.util.Optional;

public class Municipality {

	public String getName() {
		return null;
}
	public String getProvince() {
		return null;
	}

	public Collection<Branch> getBranches() {
		return null;
	}

	public Optional<Community> getCommunity() {
		return null;
	}	
	
}
