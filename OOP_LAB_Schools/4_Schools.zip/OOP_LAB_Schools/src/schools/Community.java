package schools;

import java.util.Collection;

public class Community {
	
	public enum Type { MONTANA, COLLINARE };
	
	public String getName() {
		return null;
	}
	
	public Type getType(){
		return null;
	}

	public Collection<Municipality> getMunicipalities() {
		return null;
	}
	
}
